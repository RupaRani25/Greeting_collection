# Ansible Collection - Greeting_collection.Namaste

Documentation for the collection.